export function divisao(a, b) {
    return a / b;
}