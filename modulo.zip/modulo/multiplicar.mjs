export function multiplicar(a, b) {
    return a * b;
}