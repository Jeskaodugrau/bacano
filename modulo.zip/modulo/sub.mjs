export function subtracao(a, b) {
    return a - b;
}